﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AuthenticationAPINetCore
{
    public static class Settings
    {        
        public static readonly string Secret = "marcy9d8534b48w951b9287d492b256x";
        
    }
}
